const form=document.querySelector("#form"),input=document.querySelector("#pdfs"),drop=document.querySelector("#drop"),ft=document.querySelector("#fileText"),go=document.querySelector("#go"),status=document.querySelector("#status"),results=document.querySelector("#results");
input.onchange=()=>{ft.textContent=input.files.length?`${input.files.length} PDF(s) selected`:"Choose PDF file(s)"};
["dragenter","dragover"].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add("active")}));
["dragleave","drop"].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove("active")}));
drop.addEventListener("drop",e=>{if(e.dataTransfer.files.length){input.files=e.dataTransfer.files;ft.textContent=`${input.files.length} PDF(s) selected`}});
form.onsubmit=async e=>{
 e.preventDefault();results.innerHTML="";
 if(!input.files.length){status.textContent="Please select at least one PDF.";return}
 go.disabled=true;status.textContent="Analysing and reconstructing… Please keep this page open.";
 try{
  const r=await fetch("/convert",{method:"POST",body:new FormData(form)}),j=await r.json();
  if(!r.ok)throw Error(j.error||"Conversion failed.");
  status.textContent="Conversion finished. Check the verification result below.";
  j.results.forEach(x=>{
   const d=document.createElement("div");d.className="result";
   if(x.ok){const rep=x.report;d.innerHTML=`<b>✓ ${x.name}</b><br><small>Mode: ${rep.mode} · ${rep.verification}${rep.tables?` · Tables: ${rep.tables}`:""}</small><br><a href="${x.download}">⬇ Download DOCX</a>`}
   else d.innerHTML=`<b class="bad">✕ ${x.name}</b><br><small class="bad">${x.error}</small>`;
   results.appendChild(d);
  });
 }catch(err){status.textContent=err.message}finally{go.disabled=false}
};
